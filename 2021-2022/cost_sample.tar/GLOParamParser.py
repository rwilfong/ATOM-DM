import argparse
import json
import sys
import re
import logging
import datetime

log = logging.getLogger("glo.optmizer_parameter_parser")


# **********************************************************************************************************
def wrapper(*any_arg):
    """"Wrapper to handle the ParseParams class. Calls the correct method depending on the input argument type

        Args:
            *any_arg: any single input of a str, dict, argparse.Namespace, or list

        Returns:
            argpase.Namespace: a Namespace.argparse object containing default parameters + user specified parameters
        Raises:
            TypeError: Input argument must be a configuration file (str), dict, argparse.Namespace, or list

    """
    if len(any_arg) == 1:
        inp_arg = any_arg[0]
        if isinstance(inp_arg, str):
            list_inp = parse_config_file(config_file_path=inp_arg)
            return parse_command_line(list_inp)
        elif isinstance(inp_arg, (dict, argparse.Namespace)):
            list_inp = parse_namespace(inp_arg)
            return parse_command_line(list_inp)
        elif isinstance(inp_arg, list):
            # This conditional statement checks for the positional argument '--config_file'
            # and parses the input .json configuration file into a list type input
            if inp_arg[0] == "--config_file" or inp_arg[0] == "--config":
                list_inp = parse_config_file(config_file_path=inp_arg[1])
                # If there are additional arguments beyond the config_file input
                # the following if statement properly appends the remaining arguments
                #
                if len(inp_arg) > 2:
                    just_args = [x for x in inp_arg[2:] if "--" in x]
                    for item in just_args:
                        if item in list_inp:
                            idx = list_inp.index(item)
                            if "--" in list_inp[idx + 1]:
                                list_inp[idx : idx + 1] = []
                            else:
                                list_inp[idx : idx + 2] = []
                    list_inp += inp_arg[2:]
                return parse_command_line(list_inp)
            elif len(inp_arg) == 1:
                if inp_arg[0][0:9] == "Namespace":
                    eval_arg = eval("argparse." + inp_arg[0])
                    print(eval_arg)
                else:
                    eval_arg = eval(inp_arg[0])
                if isinstance(eval_arg, (dict, argparse.Namespace)):
                    list_inp = parse_namespace(eval_arg)
                    return parse_command_line(list_inp)
                else:
                    return parse_command_line(eval_arg)
            else:
                return parse_command_line(inp_arg)
        else:
            raise TypeError(
                "Input argument must be a configuration file (str), dict, argparse.Namespace, or list"
            )
    else:
        raise TypeError(
            "Input argument must be a configuration file (str), dict, argparse.Namespace, or list"
        )


# **********************************************************************************************************


def parse_config_file(config_file_path):
    """"Method to convert a .json configuration file to a Namespace object. Does the following conversions: .json -> hierarchical dict -> flat dict -> dict_to_list.
    WARNING: if there are two identical parameters on the same hierarchical level in the config.json, the .json will inherently silence the parameter higher up on the list without flagging a duplication. However, duplicate parameters in two different hierarchies or subdictionaries will be flagged by this parser.

    Args:
        config_file_path(str): PATH to configuration .json file

    Returns:
        ParseParams.dict_to_list(newdict): a Namespace.argparse object containing default parameters + user specified parameters
    """
    # Loads the .json config file
    with open(config_file_path) as f:
        config = json.loads(f.read())

    # If the config file is a hierarchical dict, it flattens the dictionary, otherwise, the dict is unchanged
    flat_dict = flatten_dict(config, {})

    # there are several optional naming conventions for parameters, the following lines of code replace the optional names with the expected parameter names
    replace_json_names_dict = {
        "dataset_bucket": "bucket",
        "feat_type": "featurizer",
        "y": "response_cols",
        "optimizer": "optimizer_type",
    }
    orig_keys = list(flat_dict.keys())
    for key, vals in replace_json_names_dict.items():
        if key in orig_keys:
            flat_dict[vals] = flat_dict.pop(key)

    # dictionary comprehension that retains only the keys that are in the accepted list of parameters
    if "hyperparam" in orig_keys and flat_dict["hyperparam"] == True:
        default = list_defaults(hyperparam=True)
    else:
        default = list_defaults()
    keep = list(vars(default).keys())
    newdict = {k: flat_dict[k] for k in keep if k in flat_dict}

    # Writes a warning for any arguments that are not in the default list of parameters
    extra_keys = [x for x in list(flat_dict.keys()) if x not in newdict.keys()]
    if len(extra_keys) > 0:
        log.warning(
            str(extra_keys)
            + " are not part of the accepted list of parameters and will be ignored"
        )
    newdict["config_file"] = config_file_path
    return dict_to_list(newdict)


# ***********************************************************************************************************
def flatten_dict(inp_dict, newdict={}):
    """Method to flatten a hierarchical dictionary. Used in parse_config_file(). Throws error if there are duplicated keys in the dictionary. WARNING: immediately throws error upon first detection of duplications.

    Args:
        inp_dict(dict): hierarchical dictionary
        newdict(empty dict): empty dictionary, name of output flattened dictionary

    Returns:
        newdict(dict): Flattened dictionary.
    """

    for key, val in inp_dict.items():
        if isinstance(val, dict):
            flatten_dict(val, newdict)
        else:
            if key in newdict and newdict[key] != val:
                log.warning(
                    str(key)
                    + " appears several times. Overwriting with value: "
                    + str(val)
                )
                newdict[key] = val
            else:
                newdict[key] = val
    return newdict


# ***********************************************************************************************************


def parse_namespace(namespace_params=None):
    """Method to convert namespace object to dictionary, then pass the value to dict_to_list. Will simply pass a dictionary

    Args:
        namespace_params(dictionary or namespace.argparse object)
    Returns:
        ParseParams.dict_to_list(newdict): a Namespace.argparse object containing default parameters + user specified parameters
    """
    if namespace_params is None:
        return dict_to_list(namespace_params)
    if isinstance(namespace_params, argparse.Namespace):
        namespace_params = vars(namespace_params)
    # If the namespace object or dictionary is a hierarchical dict, it flattens the dictionary, otherwise, the dict is unchanged

    flat_dict = flatten_dict(namespace_params, {})

    # there are several optional naming conventions for parameters, the following lines of code replace the optional names with the expected parameter names
    replace_json_names_dict = {
        "dataset_bucket": "bucket",
        "feat_type": "featurizer",
        "y": "response_cols",
        "optimizer": "optimizer_type",
    }
    orig_keys = list(flat_dict.keys())
    for key, vals in replace_json_names_dict.items():
        if key in orig_keys:
            flat_dict[vals] = flat_dict.pop(key)

    # dictionary comprehension that retains only the keys that are in the accepted list of parameters
    default = list_defaults()
    keep = list(vars(default).keys())
    newdict = {k: flat_dict[k] for k in keep if k in flat_dict}

    # Writes a warning for any arguments that are not in the default list of parameters
    extra_keys = [x for x in list(flat_dict.keys()) if x not in newdict.keys()]
    if len(extra_keys) > 0:
        log.warning(
            str(extra_keys)
            + " are not part of the accepted list of parameters and will be ignored"
        )

    return dict_to_list(newdict)


# ***********************************************************************************************************


def dict_to_list(inp_dictionary, replace_spaces=False):
    """Method to convert dictionary to a modified list of strings for input to argparse. Adds a '--' in front of keys in the dictionary.

    Args:
        inp_dictionary (dict): Flat dictionary of parameters
        replae_spaces (bool): A flag for replace spaces with replace_spaces_str for handling spaces in command line.
    Returns:
        ParseParams.parse_command_line(list): a Namespace.argparse object containing default parameters + user specified parameters
        None if inp_dictionary is None
    """

    # if replace_spaces is true, replaces spaces with replace_spaces_str for os command line calls
    replace_spaces_str = "@"
    if not isinstance(inp_dictionary, dict):
        raise ValueError("input to dict_to_list should be a dictionary!")

    # Handles optional names for the dictionary.
    optional_names_dict = {
        "dataset_bucket": "bucket",
        "feat_type": "featurizer",
        "y": "response_cols",
        "optimizer": "optimizer_type",
    }
    orig_keys = list(inp_dictionary.keys())
    for key, vals in optional_names_dict.items():
        if key in orig_keys:
            inp_dictionary[vals] = inp_dictionary.pop(key)
    temp_list_to_command_line = []

    # Special case handling for arguments that are False or True by default
    default_false = [
        "previously_split",
        "uncertainty",
        "use_shortlist",
        "datastore",
        "save_results",
        "tab_latent_reps",
        "tab_tsne",
        "tuned",
        "visualize_results",
        "verbose",
        "hyperparam",
        "split_only",
        "usecuda",
    ]
    default_true = ["transformers", "compute_metrics", "previously_featurized"]
    for key, value in inp_dictionary.items():
        if key in default_false:
            true_options = ["True", "true", "ture", "TRUE", "Ture"]
            if str(value) in true_options:
                temp_list_to_command_line.append("--" + str(key))
        elif key in default_true:
            false_options = ["False", "false", "flase", "FALSE", "Flase"]
            if str(value) in false_options:
                temp_list_to_command_line.append("--" + str(key))
        else:
            temp_list_to_command_line.append("--" + str(key))
            # Special case handling for null values
            null_options = [
                "null",
                "Null",
                "none",
                "None",
                "N/A",
                "n/a",
                "NaN",
                "nan",
                "NAN",
                "NONE",
                "NULL",
            ]
            if str(value) in null_options:
                temp_list_to_command_line.append("None")
            elif isinstance(value, list):
                sep = ","
                newval = sep.join([str(item) for item in value])
                if replace_spaces == True:
                    temp_list_to_command_line.append(
                        newval.replace(" ", replace_spaces_str)
                    )
                else:
                    temp_list_to_command_line.append(newval)
            else:
                newval = str(value)
                if replace_spaces == True:
                    temp_list_to_command_line.append(
                        newval.replace(" ", replace_spaces_str)
                    )
                else:
                    temp_list_to_command_line.append(newval)
    return temp_list_to_command_line


# ***********************************************************************************************************


def list_defaults(hyperparam=False):
    """Creates temporary required variables, to generate a Namespace.argparse object of defaults.

    Returns:
        ParseParams.parse_command_line(list): a Namespace.argparse object containing default parameters
    """
    # TODO: These required_vars are no longer required, but are very convenient for testing. Replace these vars after refactoring testing.
    if hyperparam:
        required_vars = ["--optimizer_type", "GeneticOptimzer"]
    else:
        required_vars = ["--optimizer_type", "GeneticOptimzer"]
    return parse_command_line(required_vars)


# ***********************************************************************************************************


def parse_command_line(args=None):
    """Parses a command line argument or a specifically formatted list of strings into a Namespace.argparse object.

    String input is in the following format:
        args = ['--arg1','val1','--arg2','val2','--arg3','val3']

    Args:
        args(None or list): If args is none, parse_command_line parses sys.argv if it . If args is a list, the list is parsed
    Returns:
        parsed_args: a Namespace.argparse object containing default parameters + user specific parameters

    """

    # The following conditional checks for duplicates in the input list
    if args is not None:
        if isinstance(args, str):
            newlist = re.split(" ", args)
        else:
            newlist = args
        just_args = [x for x in newlist if "--" in x]
        duplicates = set([x for x in just_args if just_args.count(x) > 1])
        if len(duplicates) > 0:
            raise ValueError(str(duplicates) + " appears several times. ")

    parser = argparse.ArgumentParser(
        description="run GLO", formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )

    # ***********************************************************************************************
    # type of optimizers to use
    parser.add_argument(
        "--optimizer_type",
        dest="optimizer_type",
        required=False,
        type=str,
        default="GeneticOptimzer",
        help="Type of optimizer. default = GeneticOptimzer.",
    )

    parser.add_argument(
        "--optimization",
        dest="optimization",
        required=False,
        type=str,
        default="minimize",
        help="direction of the cost optimization for the genetic optimizer. option [minimize, maximize]",
    )

    parser.add_argument(
        "--verbose", dest="verbose", action="store_true", help="Verbose output"
    )

    parser.add_argument(
        "--selection_type",
        dest="selection_type",
        required=False,
        type=str,
        default="tournament",
        help="Type of selection for the genetic optimizer. default = tournament.",
    )

    parser.add_argument(
        "--crossover_type",
        dest="crossover_type",
        required=False,
        type=str,
        default="uniform",
        help="Type of crossover for the genetic optimizer. default = uniform.",
    )

    parser.add_argument(
        "--mutation_type",
        dest="mutation_type",
        required=False,
        type=str,
        default="random",
        help="Type of mutation for the genetic optimizer. default = random.",
    )

    parser.add_argument(
        "--max_clones",
        dest="max_clones",
        required=False,
        type=int,
        default=0,
        help="max number of clones allowed for the genetic optimizer.",
    )

    parser.add_argument(
        "--tourn_size",
        dest="tourn_size",
        required=False,
        type=int,
        default=3,
        help="tournament sizse for the genetic optimizer.",
    )

    parser.add_argument(
        "--mate_prob",
        dest="mate_prob",
        required=False,
        type=float,
        default=0.5,
        help="mating probability for the genetic optimizer.",
    )

    parser.add_argument(
        "--ind_mutate_prob",
        dest="ind_mutate_prob",
        required=False,
        type=float,
        default=0.1,
        help="individual mutation probability for the genetic optimizer.",
    )

    parser.add_argument(
        "--gene_mutate_prob",
        dest="gene_mutate_prob",
        required=False,
        type=float,
        default=0.1,
        help="gene mutation probability for the genetic optimizer.",
    )

    parser.add_argument(
        "--mutate_std",
        dest="mutate_std",
        required=False,
        type=float,
        default=1.0,
        help="mutation standard deviation for the genetic optimizer. ",
    )

    parser.add_argument(
        "--tree_mean",
        dest="tree_mean",
        required=False,
        type=float,
        default=0.0,
        help="mean of distribution of JT-VAE junction tree latent elements. ",
    )

    parser.add_argument(
        "--tree_sd",
        dest="tree_sd",
        required=False,
        type=float,
        default=5.0,
        help="SD of distribution of JT-VAE junction tree latent elements. ",
    )

    parser.add_argument(
        "--molg_mean",
        dest="molg_mean",
        required=False,
        type=float,
        default=0.0,
        help="mean of distribution of JT-VAE molecular graph latent elements. ",
    )

    parser.add_argument(
        "--molg_sd",
        dest="molg_sd",
        required=False,
        type=float,
        default=0.002,
        help="SD of distribution of JT-VAE molecular graph latent elements. ",
    )

    parser.add_argument(
        "--memetic_frac",
        dest="memetic_frac",
        required=False,
        type=float,
        default=0.1,
        help="select top X% of the top population for latent-memetic exploration.",
    )

    parser.add_argument(
        "--memetic_delta_scale",
        dest="memetic_delta_scale",
        required=False,
        type=float,
        default=0.1,
        help="the scale factor for latent-memetic step.",
    )

    parser.add_argument(
        "--memetic_delta",
        dest="memetic_delta",
        required=False,
        type=str,
        default="",
        help="the filepath contain the std column of latent variable distribution. \
        If not specified, the value will be set to 1 by optimizer.",
    )

    parser.add_argument(
        "--memetic_size",
        dest="memetic_size",
        required=False,
        type=int,
        default=1,
        help="number of genes per chromosome for latent-memetic exploration.",
    )

    ### particle swarm optimizer - specific
    parser.add_argument(
        "--upper_bound",
        dest="upper_bound",
        required=False,
        type=int,
        default=None,
        help="upper_bound of the positions.",
    )
    parser.add_argument(
        "--lower_bound",
        dest="lower_bound",
        required=False,
        type=int,
        default=None,
        help="upper_bound of the positions.",
    )
    parser.add_argument(
        "--inertia",
        dest="inertia",
        required=False,
        type=float,
        default=0.5,
        help="inertia of the velocitiy component",
    )
    parser.add_argument(
        "--init_velocity_scale",
        dest="init_velocity_scale",
        required=False,
        type=float,
        default=0.02,
        help="initial velocity_scale.",
    )
    parser.add_argument(
        "--swarm_attraction",
        dest="swarm_attraction",
        required=False,
        type=float,
        default=0.2,
        help="velocity coefficient to the swarm best position. ",
    )
    parser.add_argument(
        "--self_attraction",
        dest="self_attraction",
        required=False,
        type=float,
        default=0.1,
        help="velocity coefficient to the individual best position. ",
    )

    # ***********************************************************************************************
    # args specific to Scorer
    parser.add_argument(
        "--scorer_type",
        dest="scorer_type",
        required=False,
        type=str,
        default="CostinfoScorer",
        help="Type of scorer for the Scorer. default = CostinfoScorer.",
    )

    parser.add_argument(
        "--costinfo_path",
        dest="costinfo_path",
        required=False,
        type=str,
        default="",
        help="filepath to the costinfo",
    )

    # ***********************************************************************************************
    # args specific to predictor
    parser.add_argument(
        "--predictor_type",
        dest="predictor_type",
        required=False,
        type=str,
        default="CostinfoPredictor",
        help="Type of prdictor. default = CostinfoPredictor.",
    )
    parser.add_argument(
        "--filterfamily",
        dest="filterfamily",
        required=False,
        type=str,
        default="all",
        help='filter family used in PAINS fileter: "all", "A", "B", "C". default all. ',
    )

    # args specific to featurizer
    parser.add_argument(
        "--featurizer_type",
        dest="featurizer_type",
        required=False,
        type=str,
        default="mordred",
        help="featurizer_type. default = mordred",
    )

    # ***********************************************************************************************
    # args specific to VAE
    parser.add_argument(
        "--VAE_type",
        dest="VAE_type",
        required=False,
        type=str,
        default="jtnn",
        help="Type of vae. default = jtnn.",
    )

    parser.add_argument(
        "--workers",
        dest="workers",
        type=int,
        default=1,
        help="Worker pool size for multiprocessing",
    )

    parser.add_argument("--device", dest="device", default="cpu", help="Device for VAE")

    parser.add_argument(
        "--txt_to_encode",
        dest="txt_to_encode",
        required=False,
        type=str,
        default="/home/deng6/active_learning/Loop/ChEMBL24_100.txt",  # TODO (derek): we need to change this to something that lives in the repo
        help="filepath to SMILES txt",
    )

    parser.add_argument(
        "--csv_to_decode",
        dest="csv_to_decode",
        required=False,
        type=str,
        default="/home/deng6/active_learning/Loop/ChEMBL24_100_latent.csv",  # TODO (derek): we need to change this to something that lives in the repo
        help="filepath to latent csv",
    )

    parser.add_argument(
        "--vae_path",
        dest="vae_path",
        required=False,
        type=str,
        default="icml18_jtnn/fast_molvae/moses-h450z56/model.iter-400000",
        help="filepath to the vae model",
    )

    parser.add_argument(
        "--vocab_path",
        dest="vocab_path",
        required=False,
        type=str,
        default="icml18_jtnn/data/moses/vocab.txt",
        help="filepath to the vae vocab txt",
    )

    parser.add_argument(
        "--moses_config",
        dest="moses_config",
        required=False,
        type=str,
        default=None,
        help="config file to use for loading models from moses framework",
    )

    parser.add_argument(
        "--lbann_weights_dir",
        dest="lbann_weights_dir",
        required=False,
        type=str,
        default=None,
        help="directory that stores the weights for lbann trained model",
    )

    parser.add_argument(
        "--lbann_load_epoch",
        dest="lbann_load_epoch",
        required=False,
        type=int,
        default=None,
        help="indicate which epoch to load weights from for lbann trained model",
    )

    parser.set_defaults(usecuda=False, verbose=False)

    parsed_args = parser.parse_args(args)
    return parsed_args


# ***********************************************************************************************************


def main(argument):
    """Entry point when script is run from a shell"""
    if argument[0] in ["--help", "-h"]:
        params = parse_command_line(argument)
    else:
        params = wrapper(argument)
        print(params)
    return params


# ***********************************************************************************************************

if __name__ == "__main__" and len(sys.argv) > 1:
    """Entry point when script is run from a shell. Raises an error if there are duplicate arguments"""
    just_args = [x for x in sys.argv if "--" in x]
    duplicates = set([x for x in just_args if just_args.count(x) > 1])
    if len(duplicates) > 0:
        raise ValueError(str(duplicates) + " appears several times. ")
    main(sys.argv[1:])
    sys.exit(0)
