####################################################################
## From ATOM Generative Molecular Design Open Source software
####################################################################
import numpy as np
import pandas as pd
import sys

import logging
Log = logging.getLogger(__name__)

def create_scorer(params):
    if params.scorer_type.lower() == "costinfoscorer":
        return CostinfoScorer(params)
    else:
        raise ValueError("Unknown scorer_type %s" % params.scorer_type)

def rectified_exp(values, targ_min, targ_max, scale=1.0, allow_neg=False):
    """
    Computes a rectified shifted exponential cost function of the differencs between values
    and targ_min and/or targ_max. 'Rectified' means that the cost function isn't
    negative for values within the (targ_min, targ_max) range, unless 'allow_neg' is True. 
    Either targ_min or targ_max can be NaN, in which case the other range constraint is enforced only.
    """
    if not np.isnan(targ_min):
        if np.isnan(targ_max):
            cost = np.exp((targ_min - values)/scale) - 1.0
            if allow_neg:
                return cost
            else:
                return np.maximum(cost, 0.)
        else:
            cost = np.exp(np.maximum((targ_min - values)/scale, (values - targ_max)/scale)) - 1.0
            if allow_neg:
                return cost
            else:
                return np.maximum(cost, 0.)
    elif not np.isnan(targ_max):
        cost = np.exp((values - targ_max)/scale) - 1.
        if allow_neg:
            return cost
        else:
            return np.maximum(cost, 0.)
    else:
        raise Exception('Either target_min or target_max must be specified in costinfo table')


def rectified_linear(values, targ_min, targ_max, scale=1.0, allow_neg=False):
    """
    Computes a rectified linear function of the differences between values and either
    targ_min or targ_max, whichever is not NaN. 'Rectified' means that the cost function isn't
    negative for values within the (targ_min, targ_max) range, unless 'allow_neg' is True. 
    Either targ_min or targ_max can be NaN, in which case the other range constraint is enforced only.
    """
    if not np.isnan(targ_min):
        if np.isnan(targ_max):
            cost = (targ_min - values)/scale
            if allow_neg:
                return cost
            else:
                return np.maximum(cost, 0.)
        else:
            cost = np.maximum((targ_min - values)/scale, (values - targ_max)/scale)
            if allow_neg:
                return cost
            else:
                return np.maximum(cost, 0.)
    elif not np.isnan(targ_max):
        cost = (values - targ_max)/scale
        if allow_neg:
            return cost
        else:
            return np.maximum(cost, 0.)
    else:
        raise Exception('Either target_min or target_max must be specified in costinfo table')


class Scorer(object):
    def __init__(self, params, **kwargs):
        self.params = params


# Should this be CostInfoScorer for consistency?
class CostinfoScorer(Scorer):
    def __init__(self, params, **kwargs):
        super().__init__(params, **kwargs)
        self.costinfo_path    = self.params.costinfo_path
        self.validation_level = 'none' # For future implementation as argument
        
        #self.costinfo = pd.read_csv(self.costinfo_path).fillna("")     
        self.costinfo = pd.read_csv(self.costinfo_path)
    

    def validate(cmpds):
        # Not tested yet, but intended to do some basic level of costinfo/compound validation
        errors = ""
        if level not in ["warning", "error", "none"]:
            raise Exception('Validation level must be "error", "warning", or "none"')

        missing = np.setdiff1d(
            len(np.intersect1d(self.costinfo["Name"], cmpds.columns))
        )
        if len(missing) > 1:
            errors += "Compound Info missing columns for cost scoring: " + str(missing)

        # Should also validate numerical types, weights, and directions here

        if (self.validation_level == "warning") & (len(errors) > 0):
            import warnings

            warnings.warn(errors)
        elif (self.validation_level == "error") & (len(errors) > 0):
            raise Exception(errors)

    def score(self, cmpd_df, return_costs=True):
        """
        Compute an overall cost score for each compound listed in cmpd_df. The columns of cmpd_df
        are expected to include the input criteria in the costinfo table associated with this Scorer
        object; the column names should match the values in the costinfo Name column. Returns a copy
        of cmpd_df with an additional 'cost' column holding the cost score. If return_costs is True,
        it will also contain the individual terms in the cost function, with names of the form
        '<criterion>_cost'.
        """
        cost = np.zeros(len(cmpd_df))
        if self.validation_level is not 'none':
            self.validate(cmpd_df)
        result_df = cmpd_df.copy(deep=False)
        
        for idx, criteria in self.costinfo.iterrows():
            Log.debug("Computing cost terms for %s" % criteria['Name'])
            Log.debug(f"cmpd_df: {cmpd_df}")
            try: 
                if criteria['Name'] not in ["docking_score", "fusion_score"]:
                    value = cmpd_df[criteria['Name']].values
                elif criteria['Name'] == "docking_score":
                    cmpd_df = cmpd_df.assign(docking_score=cmpd_df['docking_score'].apply(lambda x: min(x) if isinstance(x, list) else x))
                    value = cmpd_df['docking_score'].values
                elif criteria['Name'] == "fusion_score":
                    cmpd_df = cmpd_df.assign(fusion_score=cmpd_df['fusion_score'].apply(lambda x: max(x) if isinstance(x, list) else x))
                    value = cmpd_df['fusion_score'].values
            except KeyError as e:
                Log.error(
                    f"Prediction data frame lacks column for model "
                    f"{criteria['Name']}"
                )
                Log.error(
                    f"Available columns: {', '.join(cmpd_df.columns.values)}"
                )
                raise

            try: 
                costfun = str() + str(criteria['CostFunction'])
                costfun = costfun.replace(' ','').lower()
                targ_min = criteria['Target_min']
                targ_max = criteria['Target_max']
                scale = criteria.get('Scale', 1.0)
                allow_neg = criteria.get('Allow_neg', False)

                if costfun == 'exp':
                    if not allow_neg:
                        Log.debug(f"Cost is rectified exp({value[0]}, {targ_min}, {targ_max})")
                    else:
                        Log.debug(f"Cost is exp({value[0]}, {targ_min}, {targ_max}, {scale})")
                    dcost = rectified_exp(value, targ_min, targ_max, scale, allow_neg)
                elif costfun == 'linear':
                    if not allow_neg:
                        Log.debug(f"Cost is rectified linear({value[0]}, {targ_min}, {targ_max}, {scale})")
                    else:
                        Log.debug(f"Cost is linear({value[0]}, {targ_min}, {targ_max}, {scale})")
                    dcost = rectified_linear(value, targ_min, targ_max, scale, allow_neg)
                elif costfun == 'binary':
                    # Use Target_min for desired classification value
                    dcost = np.array(value != targ_min, dtype=float)
                else:
                    raise Exception('Unrecognized Cost Function: ' + self.costinfo['CostFunction'])
                
                dcost *= criteria['Weight']
                if return_costs:
                    cost_col = '%s_cost' % criteria['Name']
                    result_df[cost_col] = dcost
                cost += dcost

                sys.stdout.flush()

            except Exception as e:
                print("A model was not used {}".format(e))
                cost = np.NaN
                raise

        result_df['cost'] = cost
        return result_df

