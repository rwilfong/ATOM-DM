import Scorer, GLOParamParser
import pandas as pd

costinfo_path='team1_costinfo.csv'
test_pred='team1_test_pred.csv'
#costinfo_path='team3_costinfo.csv'
#test_pred='team3_test_pred.csv'

pred_df=pd.read_csv(test_pred)
cost_check=pd.read_csv(costinfo_path)
glo_params = dict(
    costinfo_path=costinfo_path,
    predictor_type='costinfoscorer',
    featurizer_type='ecfp',
    filterfamily=None)
params = GLOParamParser.wrapper(glo_params)
scorer = Scorer.create_scorer(params)
print('Compute cost scores')
score_df = scorer.score(pred_df,return_costs=True)

save_cost_scores='test_output.csv'
score_df.to_csv(save_cost_scores,index=False)
